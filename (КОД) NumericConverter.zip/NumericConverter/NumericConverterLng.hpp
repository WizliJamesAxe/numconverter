﻿enum {
  MTitle,

  MTextType,
  MTextFormat,
  MTextCountInLine,
  MTextSuffix,
  MTextOut,

  MTextZeroCount,
  MTextEmptySuffix,
  MTextSomeError,

  MTextConverting,

  MTypeInt8,
  MTypeInt16,
  MTypeInt32,
  MTypeInt64,

  MTypeFloat,
  MTypeDouble,

  MTypeSigned,
  MTypeUnsigned,

  MButtonGO,
  MButtonCancel,
};
