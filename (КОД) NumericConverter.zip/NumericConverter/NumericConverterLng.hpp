﻿enum {
  MTitle,

  MTextType,
  MTextFormat,
  MTextCountInLine,
  MTextSuffix,
  MTextExp,
  MTextOut,

  MTextZeroCount,
  MTextEmptySuffix,
  MTextSomeError,

  MTextConverting,

  MTypeInt8,
  MTypeInt16,
  MTypeInt32,
  MTypeInt64,

  MTypeFloat,
  MTypeDouble,

  MTypeSigned,
  MTypeUnsigned,

  MButtonGO,
  MButtonCancel,
};
